/************************************************************************
 * RunTiny.cpp															*
 *																		*
 *	Given a .TNC file as input, this program emulates the TINY 			*
 *  architecture and "runs" the TINY program.							*
 ************************************************************************/

#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

const char VERSION[] = "4.2015";

const int MAXMEMORYADDRESS =    899;
const int MAXINT           =  99999;
const int MININT           = -99999;
const int MAXLINE          =     80;
const int MAXMSG           =     80;
const int BOTTOM_OF_STACK  =    900;

int	Memory[MAXMEMORYADDRESS+1];			// Create TINY's RAM
int	ACC, IR, PC, SP, BP;				// Create the 5 TINY registers
int MaxAddressUsed;						// Marks largest address used by Code and/or Data

bool LoadMemory(char filename[]) {
	FILE *infile;
	char line[MAXLINE];
	int	address, contents, linenum, i;

	fopen_s(&infile,filename, "r");
	if (infile == NULL ) {
		printf("The file %s was not found.\n", filename);
		return false;
	}

	MaxAddressUsed = 0;

	srand( (unsigned)time( NULL ) );
	for(i=0; i <= MAXMEMORYADDRESS; i++) {
		// Initialize Memory to random values
		contents = rand() % (MAXINT + 1);
		if (contents % 100 > 94)  // Let's sprinkle in a few bells
			contents = 7;
		else if (((contents % 10) > 6) && ((contents % 10) < 9))
			contents *= -1;
		Memory[i] = contents;
	}

	fgets(line,MAXLINE,infile);
	linenum = 1; address = 0;
	while (!feof(infile) && address <= MAXMEMORYADDRESS) {
		// Read the file and load its contents into TINY RAM
		if (!strstr(line,"*")) {	// Stop if you find an asterisk (denotes start of symbol table)
			sscanf_s(line,"%d,%d",&address,&contents);  // Example input line:  021,16950
			if (address >=0 && address <= MAXMEMORYADDRESS) {
				Memory[address] = contents % (MAXINT+1);
				if (address > MaxAddressUsed) MaxAddressUsed = address;
			}
			else
				printf("Invalid address at line %d: %s\n",linenum,filename);
		}
		else
			break;

		fgets(line,MAXLINE,infile);
		linenum++;
	}
	fclose(infile);
	return true;
}

char * fmt(int n) {
	// Format integer values so that they always display 5 digits
	static char str[6];
	if (n < 0)
		sprintf_s(str,6,"-%05d",abs(n));
	else
		sprintf_s(str,6,"%05d",n);

	return str;
}

void prterr(char msg[]) {
	printf("Fatal Error: %s\n",msg);
}

int wrap(int n) {
	// Make sure an integer is within the bounds of TINY's integer representation
	while (n > MAXINT)			// If it is too big, subtract until it isn't
		n -= 2 * MAXINT + 1;
	while (n < MININT)			// If it is too small, add until it isn't
		n += 2 * MAXINT + 1;
	return n;
}

//************ TINY INSTRUCTION SET ************
bool ld(int operand) {
	char msg[MAXMSG];
	if (operand <= MAXMEMORYADDRESS) {
		// Execute LD
		ACC = Memory[operand];
		return false;
	}
	else {
		sprintf_s(msg,MAXMSG,"Invalid operand at address %03d:   %05d",PC-1,IR);
		prterr(msg);
		return true;
	}
}

bool lda(int operand) {
	ACC = operand;
	return false;
}

bool ldi(int operand) {
	char msg[MAXMSG];
	if (operand <= MAXMEMORYADDRESS)
		if (Memory[operand] >= 0 && Memory[operand] <= MAXMEMORYADDRESS) {
			// Execute LDI
			ACC = Memory[Memory[operand]];
			return false;
		}
		else {	// Redirected address leads us to an invalid address!
			sprintf_s(msg,MAXMSG,"LDI opcode at %03d (%05d) references an invalid address: %s",PC-1,IR,fmt(Memory[operand]));
			prterr(msg);
			return true;
		}
	else {
		sprintf_s(msg,MAXMSG,"Invalid operand at address %03d:   %05d",PC-1,IR);
		prterr(msg);
		return true;
	}
}

bool st(int operand) {
	char msg[MAXMSG];
	if (operand <= MAXMEMORYADDRESS) {
		// Execute ST
		Memory[operand] = ACC;
		return false;
	}
	else {
		sprintf_s(msg,MAXMSG,"Invalid operand at address %03d:   %05d",PC-1,IR);
		prterr(msg);
		return true;
	}
}

bool sti(int operand) {
	char msg[MAXMSG];
	if (operand <= MAXMEMORYADDRESS)
		if (Memory[operand] >= 0 && Memory[operand] <= MAXMEMORYADDRESS) {
			// Execute STI
			Memory[Memory[operand]] = ACC;
			return false;
		}
		else {	// Redirected address leads us to an invalid address!
			sprintf_s(msg,MAXMSG,"STI opcode at %03d (%05d) references an invalid address: %s",PC-1,IR,fmt(Memory[operand]));
			prterr(msg);
			return true;
		}
	else {
		sprintf_s(msg,MAXMSG,"Invalid operand at address %03d:   %05d",PC-1,IR);
		prterr(msg);
		return true;
	}
}

bool add(int operand) {
	ACC = wrap(ACC + Memory[operand]);
	return false;
}

bool sub(int operand) {
	ACC = wrap(ACC - Memory[operand]);
	return false;
}

bool mul(int operand) {
	ACC = wrap(ACC * Memory[operand]);
	return false;
}

bool div(int operand) {
	char msg[MAXMSG];
	if (Memory[operand] != 0) {
		ACC = wrap(ACC / Memory[operand]);
		return false;
	}
	else {					// Uh oh!  Someone is trying to divide by zero!!
		sprintf_s(msg,MAXMSG,"'Division by 0' at address %03d:  %05d",PC-1,IR);
		prterr(msg);
		return true;
	}
}

bool in() {
	char ch;

	ch = _getch();			// Read one ASCII character from keyboard
	if (ch == EOF)
		return true;

	ACC = ch;
	return false;
}

bool out() {
	int ch;
	if (ACC > 0) {
		ch = ACC % 128;		// Make sure ACC is within ASCII table limits
		if (ch > 0) {
			_putch(ch);		// Send one ASCII character to the screen
		}
	}
	return false;
}

bool jmp(int operand) {
	PC = operand;
	return false;
}

bool jg(int operand) {
	if (ACC > 0)
		PC = operand;
	return false;
}

bool jge(int operand) {
	if (ACC >= 0)
		PC = operand;
	return false;
}

bool je(int operand) {
	if (ACC == 0)
		PC = operand;
	return false;
}

bool jne(int operand) {
	if (ACC != 0)
		PC = operand;
	return false;
}

bool jl(int operand) {
	if (ACC < 0)
		PC = operand;
	return false;
}

bool jle(int operand) {
	if (ACC <= 0)
		PC = operand;
	return false;
}

bool printn() {			// Built-in ROM routine for PRINTN
	printf("%d",ACC);
	return false;
}

bool inputn() {			// Built-in ROM routine for INPUTN
	char str[MAXMEMORYADDRESS];
	gets_s(str,MAXMEMORYADDRESS);		// Allow non-digit errors
	if (sscanf_s(str, "%d", &ACC) > 0) {			// Try to convert the text string to an integer
		if (ACC < MININT || ACC > MAXINT) {
			printf("  *WARNING* Invalid integer\n");
			ACC = wrap(ACC);
		}
	}
	else {
		printf("  *WARNING* Invalid integer\n");
	}
	return false;
}

bool printc() {			// Built-in ROM routine for PRINTC / PRINTS
	char str[MAXMEMORYADDRESS];
	int i, lc;

	i = 0;
	lc = ACC;

	// Build a temporary string from contents of Memory beginning at address = ACC
	while (Memory[lc] != 0 && lc <= MAXMEMORYADDRESS) {
		str[i] = Memory[lc] % 128;  // Make sure the value is within ASCII table
		i++; lc++;
	}
	if (lc > MAXMEMORYADDRESS) {
		prterr("Null terminator not found for string.");
		return true;
	}
	str[i] = '\0';

	printf("%s",str);
	return false;
}

bool inputc() {			// Built-in ROM routine for INPUTC
	char str[MAXMEMORYADDRESS];
	int i, lc;

	gets_s(str,MAXMEMORYADDRESS);
	i = 0;
	lc = ACC;
	while (str[i] != '\0') {
		if (lc <= MAXMEMORYADDRESS)
			Memory[lc] = str[i];
		else {
			prterr("String exceeds available memory");
			return true;
		}
		i++; lc++;
	}
	Memory[lc] = '\0';
	return false;
}

bool call(int operand) {
	char msg[MAXMSG];
	bool stat;

	if (SP <= MaxAddressUsed+2) {				// Watch out for stack overflow
		sprintf_s(msg,MAXMSG,"Stack Overflow at address %03d:  %05d",PC-1,IR);
		return true;
	}

	// If operand corresponds to ROM routines, call appropriate function
	switch (operand) {
	case 900:	stat = printn();	return stat;
	case 925:	stat = printc();	return stat;
	case 950:	stat = inputn();	return stat;
	case 975:	stat = inputc();	return stat;
	}
	
	if (operand > MAXMEMORYADDRESS) {	// Watch out for illegal memory address (such as 901)
		sprintf_s(msg,MAXMSG,"Invalid operand at address %03d:  %05d",PC-1,IR);
		prterr(msg);
		return true;
	}
	// Execute call
	SP--;
	Memory[SP] = PC;
	PC = operand;
	
	SP--;
	Memory[SP] = BP;
	BP = SP;
	return false;
}

bool ret() {
	char msg[MAXMSG];
	if (SP > MAXMEMORYADDRESS-1) {		// Watch out for stack underflow
		sprintf_s(msg,MAXMSG,"Stack Underflow at address %03d:  %05d",PC-1,IR);
		prterr(msg);
		return true;
	}
	// Execute ret
	SP = BP;
	BP = Memory[SP];
	SP++;
	
	PC = Memory[SP];
	SP++;
	return false;
}

bool push() {
	char msg[MAXMSG];
	if (SP <= MaxAddressUsed-1) {						// Watch out for stack overflow
		sprintf_s(msg,MAXMSG,"Stack Overflow at address %03d:  %05d",PC-1,IR);
		prterr(msg);
		return true;
	}
	// Execute PUSH
	SP--;
	Memory[SP] = ACC;
	return false;
}

bool push(int operand) {
	char msg[MAXMSG];
	if (SP <= MaxAddressUsed - 1) {						// Watch out for stack overflow
		sprintf_s(msg, MAXMSG, "Stack Overflow at address %03d:  %05d", PC - 1, IR);
		prterr(msg);
		return true;
	}
	if (operand <= MAXMEMORYADDRESS) {
		// Execute PUSH x
		SP--;
		Memory[SP] = Memory[operand];
		return false;
	}
	else {
		sprintf_s(msg, MAXMSG, "Invalid operand at address %03d:   %05d", PC - 1, IR);
		prterr(msg);
		return true;
	}
}

bool pusha(int operand) {
	char msg[MAXMSG];
	if (SP <= MaxAddressUsed - 1) {						// Watch out for stack overflow
		sprintf_s(msg, MAXMSG, "Stack Overflow at address %03d:  %05d", PC - 1, IR);
		prterr(msg);
		return true;
	}
	if (operand <= MAXMEMORYADDRESS) {
		// Execute PUSH x
		SP--;
		Memory[SP] = operand;
		return false;
	}
	else {
		sprintf_s(msg, MAXMSG, "Invalid operand at address %03d:   %05d", PC - 1, IR);
		prterr(msg);
		return true;
	}
}
bool pop() {
	char msg[MAXMSG];
	if (SP > MAXMEMORYADDRESS) {		// Watch out for stack underflow
		sprintf_s(msg,MAXMSG,"Stack Underflow at address %03d:  %05d",PC-1,IR);
		prterr(msg);
		return true;
	}
	// Execute POP
	ACC = Memory[SP];
	SP++;
	return false;
}

bool pop(int operand) {
	char msg[MAXMSG];
	if (SP > MAXMEMORYADDRESS) {		// Watch out for stack underflow
		sprintf_s(msg, MAXMSG, "Stack Underflow at address %03d:  %05d", PC - 1, IR);
		prterr(msg);
		return true;
	}
	if (operand <= MAXMEMORYADDRESS) {
		// Execute POP x
		Memory[operand] = Memory[SP];
		SP++;
		return false;
	}
	else {
		sprintf_s(msg, MAXMSG, "Invalid operand at address %03d:   %05d", PC - 1, IR);
		prterr(msg);
		return true;
	}
	return false;
}

bool ldparm(int operand) {
	char msg[MAXMSG];
	if (BP < BOTTOM_OF_STACK) {
		if (operand > 0 && (BP+operand+1) <= MAXMEMORYADDRESS ) {
			// Execute LDPARM
			ACC = Memory[BP+operand+1];
			return false;
		}
		else {
			sprintf_s(msg,MAXMSG,"Invalid operand at address %03d:   %05d",PC-1,IR);
			prterr(msg);
			return true;
		}
	}
	else {
		sprintf_s(msg,MAXMSG,"Invalid attempt to load non-existent parameter at address %03d:   %05d",PC-1,IR);
		prterr(msg);
		return true;
	}
}

//************ END OF TINY INSTRUCTION SET ************

bool Decode_Execute()
{	int opcode, operand;
	char msg[MAXMSG];
	bool stop;
	
	if (IR >= 0) {
		// Split the instruction apart into opcode and operand
		opcode = IR / 1000;
		operand = IR % 1000;
	}
	else	// Uh oh!  We have a negative (and thus invalid) instruction!
	{	opcode = 99;
		operand = abs(IR) % 1000;
	}

	if (opcode == 0) return true;	// Found the STOP instruction!

	stop = false;
	switch (opcode) {
	case  1:	stop = ld(operand);		break;
	case  2:	stop = ldi(operand);	break;
	case  3:	stop = lda(operand);	break;
	case  4:	stop = st(operand);		break;
	case  5:	stop = sti(operand);	break;
	case  6:	stop = add(operand);	break;
	case  7:	stop = sub(operand);	break;
	case  8:	stop = mul(operand);	break;
	case  9:	stop = div(operand);	break;
	case 10:	stop = in();			break;
	case 11:	stop = out();			break;
	case 12:	stop = jmp(operand);	break;
	case 13:	stop = jg(operand);		break;
	case 14:	stop = jl(operand);		break; 
	case 15:	stop = je(operand);		break;
	case 16:	stop = call(operand);	break;
	case 17:	stop = ret();			break;
	case 18:	stop = push();			break;	// push with no operand
	case 19:	stop = pop();			break;	// pop with no operand
	case 20:	stop = ldparm(operand);	break;
	case 21:	stop = jge(operand);	break;
	case 22:	stop = jle(operand);	break;
	case 23:	stop = jne(operand);	break;
	case 24:	stop = push(operand);	break;	// push with 1 operand
	case 25:	stop = pop(operand);	break;	// pop with 1 operand
	case 26:	stop = pusha(operand);	break;
	default:
		stop = true;
		sprintf_s(msg,MAXMSG,"Invalid opcode at address %03d:   %s", PC-1, fmt(IR));
		prterr(msg);
	}
	return stop;
}

void main (int argc, char ** argv) {
	char	filename[MAXMSG];
	bool	Stop;

	if (argc < 2) {
		printf("RUNTINY version: %s\n", VERSION);
		printf("Usage:  RUNTINY program.TNC\n");
		return;
	}

	strcpy_s(filename,MAXMSG,argv[1]);
	if (!strstr(filename,"."))
		strcat_s(filename,MAXMSG,".tnc");

	if (LoadMemory(filename)) {
		PC	= 0;				// Initialize PC
		ACC = 0;				// Initialize ACC
		SP	= BOTTOM_OF_STACK;	// Initialize SP
		BP  = SP;				// Initialize BP

		Stop = false;
		while (!Stop) {
			// Tiny Instruction Cycle
			IR = Memory[PC];
			PC++;
			Stop = Decode_Execute();
		}
	}
}
