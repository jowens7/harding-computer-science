/********************************************************************
 * Tiny.cpp															*
 *																	*
 * Given an input source file (with extension .TNY) this program	*
 * "assembles" the given program and generates a TINY executable	*
 * (with .TNC extension), and a listing file (with .LIS extension).	*
 * In addition, if there are syntax errors within the program,		*
 * appropriate messages are written to the console.					*
 ********************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

const char VERSION[] = "4.2015";

const char STR_TERMINAL = '\0';
const char SINGLEQUOTE	= '\'';
const char DOUBLEQUOTE	= '\"';
const char COMMENTMARK	= ';';
const char ESCAPE_CHAR	= '\\';
const int MAXADDRESS    = 899;
const int MAXSYMBOL_LEN =  80;
const int MAXTOKEN      =  80;
const int MAXSYMBOLS    = 500;
const int FILENAMESIZE  =  80;
const int MAXLINE       = 512;
const int MAXMNEMONIC   =  15;
const int MAXOPCODES    =  40;
const int MIN_NUMBER    = -99999;
const int MAX_NUMBER    =  99999;
const int STOP		    =   0;
const int LD            =   1;
const int LDI           =   2;
const int LDA           =   3;
const int ST            =   4;
const int STI           =   5;
const int ADD           =   6;
const int SUB           =   7;
const int MUL           =   8;
const int DIV           =   9;
const int IN            =  10;
const int OUT           =  11;
const int B             =  12;
const int JMP			=  12;
const int BP            =  13;
const int JG			=  13;
const int BN            =  14;
const int JL			=  14;
const int BZ            =  15;
const int JE			=  15;
const int JSB           =  16;
const int CALL			=  16;
const int RSB           =  17;
const int RET			=  17;
const int PUSH          =  18;
const int POP           =  19;
const int LDPARAM		=  20;
const int JGE			=  21;
const int JLE			=  22;
const int JNE			=  23;
const int PUSH_WithOperand	= 24;
const int POP_WithOperand	= 25;
const int PUSHA			=  26;
const int DC            =  97;
const int DB            =  98;
const int DW			=  98;
const int DD			=  98;
const int DS            =  99;
const int PRINTN		= 900;
const int PrintInteger	= 900;
const int PRINTC		= 925;
const int PRINTS		= 925;
const int PrintString	= 925;
const int INPUTN		= 950;
const int InputInteger	= 950;
const int INPUTC		= 975;
const int INPUTS		= 975;
const int InputString	= 975;

struct sSYMBOL
{	char symbol[MAXSYMBOL_LEN];
	int  value;
};
struct sOPCODE
{	char mnemonic[MAXMNEMONIC];
	int	 opcode;
};
sSYMBOL symbol_table[MAXSYMBOLS];
sOPCODE opcode_table[MAXOPCODES];
char	sourcefile[FILENAMESIZE];
char	listfile[FILENAMESIZE];
char	tncfile[FILENAMESIZE];
int	    SymbolCnt;

void BuildOpcodeTable()
{	for (int i=0; i < MAXOPCODES; i++)
	{	strcpy_s(opcode_table[i].mnemonic,MAXMNEMONIC,"");
		opcode_table[i].opcode = -1;
	}
	strcpy_s(opcode_table[0].mnemonic,MAXMNEMONIC,"STOP"); opcode_table[0].opcode  = STOP;
	strcpy_s(opcode_table[1].mnemonic,MAXMNEMONIC,"LD");   opcode_table[1].opcode  = LD;
	strcpy_s(opcode_table[2].mnemonic,MAXMNEMONIC,"LDI");  opcode_table[2].opcode  = LDI;
	strcpy_s(opcode_table[3].mnemonic,MAXMNEMONIC,"LDA");  opcode_table[3].opcode  = LDA;
	strcpy_s(opcode_table[4].mnemonic,MAXMNEMONIC,"ST");   opcode_table[4].opcode  = ST;
	strcpy_s(opcode_table[5].mnemonic,MAXMNEMONIC,"STI");  opcode_table[5].opcode  = STI;
	strcpy_s(opcode_table[6].mnemonic,MAXMNEMONIC,"ADD");  opcode_table[6].opcode  = ADD;
	strcpy_s(opcode_table[7].mnemonic,MAXMNEMONIC,"SUB");  opcode_table[7].opcode  = SUB;
	strcpy_s(opcode_table[8].mnemonic,MAXMNEMONIC,"MUL");  opcode_table[8].opcode  = MUL;
	strcpy_s(opcode_table[9].mnemonic,MAXMNEMONIC,"DIV");  opcode_table[9].opcode  = DIV;
	strcpy_s(opcode_table[10].mnemonic,MAXMNEMONIC,"IN");  opcode_table[10].opcode = IN;
	strcpy_s(opcode_table[11].mnemonic,MAXMNEMONIC,"OUT"); opcode_table[11].opcode = OUT;
	strcpy_s(opcode_table[12].mnemonic,MAXMNEMONIC,"B");   opcode_table[12].opcode = B;
	strcpy_s(opcode_table[13].mnemonic,MAXMNEMONIC,"JMP"); opcode_table[13].opcode = JMP;
	strcpy_s(opcode_table[14].mnemonic,MAXMNEMONIC,"BP");  opcode_table[14].opcode = BP;
	strcpy_s(opcode_table[15].mnemonic,MAXMNEMONIC,"JG");  opcode_table[15].opcode = JG;
	strcpy_s(opcode_table[16].mnemonic,MAXMNEMONIC,"BN");  opcode_table[16].opcode = BN;
	strcpy_s(opcode_table[17].mnemonic,MAXMNEMONIC,"JL");  opcode_table[17].opcode = JL;
	strcpy_s(opcode_table[18].mnemonic,MAXMNEMONIC,"BZ");  opcode_table[18].opcode = BZ;
	strcpy_s(opcode_table[19].mnemonic,MAXMNEMONIC,"JE");  opcode_table[19].opcode = JE;
	strcpy_s(opcode_table[20].mnemonic,MAXMNEMONIC,"JSB"); opcode_table[20].opcode = JSB;
	strcpy_s(opcode_table[21].mnemonic,MAXMNEMONIC,"CALL");opcode_table[21].opcode = CALL;
	strcpy_s(opcode_table[22].mnemonic,MAXMNEMONIC,"RSB"); opcode_table[22].opcode = RSB;
	strcpy_s(opcode_table[23].mnemonic,MAXMNEMONIC,"RET"); opcode_table[23].opcode = RET;
	strcpy_s(opcode_table[24].mnemonic,MAXMNEMONIC,"PUSH");opcode_table[24].opcode = PUSH;
	strcpy_s(opcode_table[25].mnemonic,MAXMNEMONIC,"POP"); opcode_table[25].opcode = POP;
	strcpy_s(opcode_table[26].mnemonic,MAXMNEMONIC,"LDPARAM"); opcode_table[26].opcode = LDPARAM;
	strcpy_s(opcode_table[27].mnemonic,MAXMNEMONIC,"JGE"); opcode_table[27].opcode = JGE;
	strcpy_s(opcode_table[28].mnemonic,MAXMNEMONIC,"JLE"); opcode_table[28].opcode = JLE;
	strcpy_s(opcode_table[29].mnemonic,MAXMNEMONIC,"JNE"); opcode_table[29].opcode = JNE;
	strcpy_s(opcode_table[30].mnemonic,MAXMNEMONIC,"PUSHA"); opcode_table[30].opcode = PUSHA;
	strcpy_s(opcode_table[31].mnemonic,MAXMNEMONIC,"DC");  opcode_table[31].opcode = DC;
	strcpy_s(opcode_table[32].mnemonic,MAXMNEMONIC,"DB");  opcode_table[32].opcode = DB;
	strcpy_s(opcode_table[33].mnemonic,MAXMNEMONIC,"DD");  opcode_table[33].opcode = DD;
	strcpy_s(opcode_table[34].mnemonic,MAXMNEMONIC,"DW");  opcode_table[34].opcode = DW;
	strcpy_s(opcode_table[35].mnemonic,MAXMNEMONIC,"DS");  opcode_table[35].opcode = DS;
}
bool isNumber(char s[]) {
	int i = 0, sign = 1;

	while (isspace(s[i])) i++;		// Skip over leading white space

	if (s[i] == '-' || s[i] == '+')	// Allow a leading sign
		i++;

	if (!isdigit(s[i])) return false;

	while (isdigit(s[i])) i++;		// Allow any number of digits

	while (isspace(s[i])) i++;		// Allow trailing whitespace

	return (s[i] == STR_TERMINAL);

}

bool GetNumber(char s[], int &number)
{	int i = 0, sign = 1;

	number = 0;
	while (isspace(s[i])) i++;			// Skip over leading whitespace

	if (s[i] == '+' || s[i] == '-')	{	// Allow a leading sign
		if (s[i] == '-') sign = -1;
		i++;
	}

	if (!isdigit(s[i])) return false;

	while (isdigit(s[i]))
	{	number *= 10;
		number += s[i]-'0';
		i++;
	}
	number *= sign;

	while (isspace(s[i])) i++;		// Skip over trailing whitespace

	if (number < MIN_NUMBER || number > MAX_NUMBER) return false;
	if (s[i] == STR_TERMINAL) return true;
	return false;
}
char * fmt(int n, bool space)
{	static char str[7];
	if (n < 0)
		sprintf_s(str,7,"-%05d",abs(n));
	else
	{	if (space)
			sprintf_s(str,7," %05d",n);
		else
			sprintf_s(str,7,"%05d",n);
	}
	return str;
}
void chomp(char s[])	// Remove trailing ENDL character, if present
{	size_t i;

	i = strlen(s);
	if (s[i-1] == '\n')
		s[i-1] = STR_TERMINAL;
}
void tab2space(char s[])
{	size_t i, j, NumSpaces;
	bool inString;
	i = 0;
	inString = false;
	while (s[i] != STR_TERMINAL)
	{	if (s[i] == COMMENTMARK && !inString)				// Don't modify a comment
			return;

		if (s[i] == SINGLEQUOTE || s[i] == DOUBLEQUOTE)		// Found a string delimiter
			inString = !inString;

		if (s[i] == '\t' && !inString)						// if not in string literal, replace tab with some spaces
		{	NumSpaces = (4 - i%4) - 1;						//   Number of spaces = what is needed for 4 column indent
			j = strlen(s) + NumSpaces;
			while (j > i+NumSpaces)
			{	s[j] = s[j-NumSpaces];
				j--;
			}
			for (j=i; j<=i+NumSpaces ; j++)
				s[j] = ' ';
		}
		i++;
	}
}
void StripLeadingWhite(char s[])
{	int i,j;
	i = 0; j = 0;
	while (isspace(s[i]) && s[i] != STR_TERMINAL) i++;
	if (s[i] != STR_TERMINAL)
	{	while (s[i] != STR_TERMINAL)
		{	s[j] = s[i];
			j++; i++;
		}
		s[j] = STR_TERMINAL;
	}
	else
	{	s[0] = STR_TERMINAL;
	}
}
void StripTrailingWhite(char s[])
{	size_t i;

	i = strlen(s);
	if (i > 0)
	{
		i--;
		while (i>=0 && isspace(s[i])) i--;
		if (i>= 0)
			s[i+1] = STR_TERMINAL;
		else
			s[0] = STR_TERMINAL;
	}
}
void StripAllWhite(char s[])
{	int i,j;
	i = 0; j = 0;
	while (s[i] != STR_TERMINAL)
	{	if (!(isspace(s[i])))
		{	s[j] = s[i];
			j++;
		}
		i++;
	}
	s[j] = STR_TERMINAL;
}
char StripBeforeAfterStringLiteral(char s[])
{	int i,j;
	char stringDelimiter = '\0';

	i = 0; j = strlen(s);
	while (s[i] != SINGLEQUOTE && s[i] != DOUBLEQUOTE && s[i] != STR_TERMINAL) i++;

	if (s[i] != STR_TERMINAL) {
		stringDelimiter = s[i];

		while (j >= 0 && s[j] != stringDelimiter) j--;

		if (i < j) {
			int k = 0;
			while (i <= j) {
				s[k] = s[i];
				i++; k++;
			}
			s[k] = STR_TERMINAL;
		}
		else
			stringDelimiter = '\0';
	}
	else {
		s[0] = STR_TERMINAL;
	}

	return stringDelimiter;
}
/*
void StripAfterStringLiteral(char s[])
{	size_t i;

	i = strlen(s);
	if (i>0)
	{	while (i>=0 && s[i] != SINGLEQUOTE && s[i] != DOUBLEQUOTE) i--;
		if (i>=0) 
			s[i] = STR_TERMINAL;
		else
			s[0] = STR_TERMINAL;
	}
}
*/

void StripComment(char s[])
{	int i = 0;
	char StringDelimiter = ' ';
	bool inString = false;
	
	while (s[i] != STR_TERMINAL) {
		if (!inString && (s[i] == SINGLEQUOTE || s[i] == DOUBLEQUOTE)) {
			inString = true;
			StringDelimiter = s[i];
		}
		else {
			if (inString && s[i] == ESCAPE_CHAR && s[i+1] != STR_TERMINAL) i += 2;

			if (inString && s[i] == StringDelimiter) {
				inString = false;
			}
		}
		
		if (!inString && s[i] == COMMENTMARK) {
			s[i] = STR_TERMINAL;
			break;
		}
		i++;
	}
}
void ConvertEscapeChars (char s[]) {
	int i = 0;
	char StringDelimiter = ' ';
	bool inString = false;
	
	while (s[i] != STR_TERMINAL) {
			if (!inString && (s[i] == SINGLEQUOTE || s[i] == DOUBLEQUOTE)) {
			inString = true;
			StringDelimiter = s[i];
		}
		else {
			if (inString && s[i] == ESCAPE_CHAR && s[i+1] != STR_TERMINAL) {
				if (s[i+1] == SINGLEQUOTE || s[i+1] == DOUBLEQUOTE)
					s[i] = s[i+1];
				else {
					int j = i;
					while (s[j] != STR_TERMINAL) {
						s[j] = s[j+1];
						j++;
					}
				}
			}

			if (inString && s[i] == StringDelimiter) {
				inString = false;
			}
		}
		
		if (!inString && s[i] == COMMENTMARK) {
			s[i] = STR_TERMINAL;
			break;
		}
		i++;
	}
}

char * GetLabel(char s[])
{	static char label[MAXLINE];
	char t[MAXLINE];
	int  i = 0, j = 0;
	bool inString = false;

	strcpy_s(label,MAXLINE,"");
	strcpy_s(t,MAXLINE,"");

	while (s[i] != STR_TERMINAL) {
		if (s[i] == SINGLEQUOTE || s[i] == DOUBLEQUOTE) inString = !inString;
		if (s[i] == ':' && !inString) {
			strcpy_s(label,MAXLINE,s);
			label[i] = STR_TERMINAL;
			i++;
			while (s[i] != STR_TERMINAL)
			{	t[j] = s[i];
				i++; j++;
			}
			t[j] = STR_TERMINAL;
			strcpy_s(s,MAXLINE,t);
			break;
		}
		i++;
	}
	StripAllWhite(label);
	return label;
}
char * GetToken(char s[])		// Extract token delimited by whitespace
{	int i;
	char *p;
	static char t[MAXTOKEN];

	i = 0;
	p = s;
	while (isspace(*p)) p++;
	while (!(isspace(*p) || *p == STR_TERMINAL)) 
	{	t[i] = *p;
		i++;
		p++;
	}
	
	t[i] = STR_TERMINAL;
	
	i = 0;
	while (!(*p == '\n' || *p == STR_TERMINAL))
	{	s[i] = *p;
		i++;
		p++;
	}
	s[i] = STR_TERMINAL;
	return t;
	
}
void upper(char s[])
{	int i;
	i = 0;
	while (s[i] != STR_TERMINAL)
	{	if (s[i] >= 'a' && s[i] <= 'z')
			s[i] -= 'a' - 'A';
		i++;
	}
}
int GetOpcode(char s[])
{	int i;
	
	upper(s);
	i = 0;
	while (opcode_table[i].opcode != -1 && strcmp(opcode_table[i].mnemonic,s) != 0)
		i++;
	if (strcmp(opcode_table[i].mnemonic,s) == 0)
		return opcode_table[i].opcode;
	else
		return -1;
}
bool BuildSymbolTable()
{	int lc, i, size;
	FILE *infile;
	char line[MAXLINE];
	char *token, *label;
	int	 opcode;
	bool inString, OneLastTime;

	if( fopen_s(&infile,sourcefile, "r") )
	{	printf("The file %s was not found.\n", sourcefile);
		return false;
	}

	lc = 0;
	SymbolCnt = 0;
	OneLastTime = false;
	strcpy_s(line,MAXLINE,"");
	fgets(line,MAXLINE,infile);
	if (feof(infile) && strlen(line) > 0) {OneLastTime = true;}
	while (!feof(infile) || OneLastTime)
	{	if (lc > MAXADDRESS)
		{	break;
		}
		chomp(line);
		StripComment(line);
		ConvertEscapeChars(line);
		label = GetLabel(line);
		if (strlen(label))// && !isNumber(label))
		{	upper(label);
			strcpy_s(symbol_table[SymbolCnt].symbol,MAXSYMBOL_LEN,label);
			symbol_table[SymbolCnt].value = lc;
			SymbolCnt++;;
		}
		token = GetToken(line);
		opcode = GetOpcode(token);
		if (opcode >= 0)
			if (opcode == DS)
			{	if (GetNumber(line,size))
				{	if (size >= 0 && size + lc <= MAXADDRESS)
					{	lc += size;
					}
					else if (size + lc > MAXADDRESS)
					{	lc = MAXADDRESS;
					}
				}
			}
			else if (opcode == DC) {
				char stringDelimiter = StripBeforeAfterStringLiteral(line);
				if (stringDelimiter != '\0') {
					inString = false; i = 0;
					while (line[i] != STR_TERMINAL) {
						if (inString) {
							if (line[i] == ESCAPE_CHAR && line[i+1] != STR_TERMINAL) {
								i += 2;
								lc++;
							} else if (line[i] != ESCAPE_CHAR) {
								if (line[i] == stringDelimiter)
									if (line[i+1] == stringDelimiter) {
										lc++;
										i++;
									}
									else {
										inString = !inString;
									}
								else
									lc++;
								i++;
							}

						} else if (line[i] == stringDelimiter) {
							inString = !inString;
							i++;
						}
					}
				}
			}
			else
			{	lc++;
			}
		
		if (!OneLastTime)
		{
			strcpy_s(line,MAXLINE, "");
			fgets(line,MAXLINE,infile);
			if (feof(infile) && strlen(line) > 0)
				{OneLastTime = true;}
		}
		else
		{
			OneLastTime = false;
		}
	}
	fclose(infile);
	{	strcpy_s(symbol_table[SymbolCnt].symbol,MAXSYMBOL_LEN, "PRINTN");
		symbol_table[SymbolCnt].value = PRINTN;
		SymbolCnt++;
		strcpy_s(symbol_table[SymbolCnt].symbol,MAXSYMBOL_LEN,"PRINTC");
		symbol_table[SymbolCnt].value = PRINTC;
		SymbolCnt++;;
		strcpy_s(symbol_table[SymbolCnt].symbol,MAXSYMBOL_LEN,"INPUTN");
		symbol_table[SymbolCnt].value = INPUTN;
		SymbolCnt++;
		strcpy_s(symbol_table[SymbolCnt].symbol,MAXSYMBOL_LEN,"INPUTC");
		symbol_table[SymbolCnt].value = INPUTC;
		SymbolCnt++;
		strcpy_s(symbol_table[SymbolCnt].symbol, MAXSYMBOL_LEN, "PRINTINTEGER");
		symbol_table[SymbolCnt].value = PrintInteger;
		SymbolCnt++;
		strcpy_s(symbol_table[SymbolCnt].symbol, MAXSYMBOL_LEN, "PRINTSTRING");
		symbol_table[SymbolCnt].value = PrintString;
		SymbolCnt++;
		strcpy_s(symbol_table[SymbolCnt].symbol, MAXSYMBOL_LEN, "PRINTS");
		symbol_table[SymbolCnt].value = PRINTS;
		SymbolCnt++;
		strcpy_s(symbol_table[SymbolCnt].symbol, MAXSYMBOL_LEN, "INPUTINTEGER");
		symbol_table[SymbolCnt].value = InputInteger;
		SymbolCnt++;
		strcpy_s(symbol_table[SymbolCnt].symbol, MAXSYMBOL_LEN, "INPUTS");
		symbol_table[SymbolCnt].value = INPUTS;
		SymbolCnt++;
		strcpy_s(symbol_table[SymbolCnt].symbol, MAXSYMBOL_LEN, "INPUTSTRING");
		symbol_table[SymbolCnt].value = InputString;
		SymbolCnt++;
	}
	return true;
}

int LookupSymbol(char s[])
{	int i;

	StripAllWhite(s);
	upper(s);
	i = 0;
	while (i < SymbolCnt && strcmp(symbol_table[i].symbol,s) != 0)
		i++;

	if (i < SymbolCnt)
		return symbol_table[i].value;
	else
		return -1;
}

int parseString(char line[]) {
	char tempLine[MAXLINE] = "";

	int errorCode = 0;
	char stringDelimiter = StripBeforeAfterStringLiteral(line);
	if (stringDelimiter == '\0') {
		errorCode = 1;
	}
	else {
		bool inString = false;
		size_t len = strlen(line);
		size_t i=0, j=0;
		while (i < len) {
			if (inString) {
				if (line[i] == ESCAPE_CHAR) {
					if (line[i+1] == STR_TERMINAL) {
						break;
					}
					else {
						tempLine[j] += line[i+1];
						j++;
						i++;
					}
				}
				else if (line[i] == stringDelimiter) {
					if ( line[i+1] != STR_TERMINAL) {
						if (line[i+1] == stringDelimiter) {
							tempLine[j] += line[i+1];
							j++;
							i++;
						} else {
							inString = false;
						}
					}
					else {
						inString = false;
					}
				}
				else {
					tempLine[j] += line[i];
					j++;
				}
			}
			else if (line[i] == stringDelimiter) {
				inString = true;
			}
			i++;
		}
		tempLine[j] = '\0';
		if (inString) errorCode = 2;
	}

	if (errorCode == 0) {
		for (size_t i = 0; i <= strlen(tempLine); i++) {
			line[i] = tempLine[i];
		}
	}

	return errorCode;
}

bool WriteFiles()
{	FILE *infile;
	FILE *outlist;
	FILE *outtnc;
	char line[MAXLINE],listline[MAXLINE];
	int	opcode,operand,contents;
	char *token;
	int lc, source_linenum, size;
	bool OneLastTime;
	int ErrorCnt = 0, WarningCnt = 0;

	if( fopen_s(&infile,sourcefile, "r") )
	{	printf("The file %s was not found.\n", sourcefile);
		return false;
	}

	fopen_s(&outlist,listfile,"w");
	fopen_s(&outtnc,tncfile,"w");

	time_t ltime; const int bufsize = 30; char timebuf[bufsize];time(&ltime); ctime_s(timebuf,bufsize,&ltime);
	fprintf(outlist,"Tiny Assembler Listing of %s on %s\n\n",sourcefile,timebuf);
	fprintf(outlist,"ADR  VALUE   LN  SOURCE LINE\n");
	fprintf(outlist,"---  -----  ---  -----------\n");
	lc = 0;
	source_linenum = 1;	
	OneLastTime = false;
	strcpy_s(line,MAXLINE,"");
	fgets(line,MAXLINE,infile);
	if (feof(infile) && strlen(line) > 0) {OneLastTime = true;}
	while (!feof(infile) || OneLastTime)
	{	chomp(line);
		tab2space(line);
		strcpy_s(listline,MAXLINE,line);
		StripComment(line);
		GetLabel(line);
		token = GetToken(line);
		StripLeadingWhite(line);
		StripTrailingWhite(line);
		opcode = GetOpcode(token);
		if (opcode >= STOP && opcode <= PUSHA)
		{	if (lc > MAXADDRESS)
			{	fprintf(outlist,"           ERROR: Program size exceeds available memory at line #%d\n",source_linenum);
				printf("ERROR: Program size exceeds available memory at line #%d\n",source_linenum);
				ErrorCnt++;
				break;
			}
			switch (opcode)
			{	case STOP:	// These should have no operand.
				case IN:
				case OUT:
				case RSB:
				{
					if (!GetNumber(line,operand) && LookupSymbol(line) < 0) {  // No operand?  Good!
							fprintf(outtnc,"%03d,%02d000\n",lc,opcode);
							fprintf(outlist,"%03d  %02d000  %3d  %s\n",lc,opcode,source_linenum,listline);
						}
						else {
							if (!GetNumber(line, operand)) operand = LookupSymbol(line);
							contents = opcode*1000 + operand;
							fprintf(outtnc,"%03d,%s\n",lc,fmt(contents,false));
							fprintf(outlist,"%03d %s  %3d  %s\n",lc,fmt(contents,true),source_linenum,listline);
							fprintf(outlist,"           WARNING: Unused operand in line #%d\n",source_linenum);
							printf("WARNING: Unused operand in line #%d:\n%3d  %s\n\n",source_linenum,source_linenum,listline);
							WarningCnt++;
						}
					break;
				}
				case PUSH:	// These two may or may not have an operand
				case POP:
				{
					if (!GetNumber(line, operand) && LookupSymbol(line) < 0) {	// No operand
						fprintf(outtnc, "%03d,%02d000\n", lc, opcode);
						fprintf(outlist, "%03d  %02d000  %3d  %s\n", lc, opcode, source_linenum, listline);
					}
					else {
						if (!GetNumber(line, operand)) operand = LookupSymbol(line);
						if (operand >= 0) {		// There is an operand
							int newOpcode;
							if (opcode == PUSH) newOpcode = PUSH_WithOperand;
							if (opcode == POP) newOpcode = POP_WithOperand;
							contents = newOpcode * 1000 + operand;
							fprintf(outtnc, "%03d,%s\n", lc, fmt(contents, false));
							fprintf(outlist, "%03d %s  %3d  %s\n", lc, fmt(contents, true), source_linenum, listline);
						}
						else {
							fprintf(outtnc, "%03d,%02d???\n", lc, opcode);
							fprintf(outlist, "%03d  %02d???  %3d  %s\n", lc, opcode, source_linenum, listline);
							fprintf(outlist, "           ERROR: Invalid operand in line #%d\n", source_linenum);
							printf("ERROR: Invalid operand in line #%d:\n%3d  %s\n\n", source_linenum, source_linenum, listline);
							ErrorCnt++;
						}
					}
					break;
				}
		
				default:		// All the rest must have an operand.
				{
					if (!GetNumber(line,operand)) operand = LookupSymbol(line);
					if (operand >= 0) {
						contents = opcode*1000+operand;
						fprintf(outtnc,"%03d,%s\n",lc,fmt(contents,false));
						fprintf(outlist,"%03d %s  %3d  %s\n",lc,fmt(contents,true),source_linenum,listline);
					}
					else {
						fprintf(outtnc,"%03d,%02d???\n",lc,opcode);
						fprintf(outlist,"%03d  %02d???  %3d  %s\n",lc,opcode,source_linenum,listline);
						fprintf(outlist,"           ERROR: Invalid or missing operand in line #%d\n",source_linenum);
						printf("ERROR: Invalid or missing operand in line #%d:\n%3d  %s\n\n",source_linenum,source_linenum,listline);
						ErrorCnt++;
					}
				}
			}
			lc++;
		}
		else if (opcode == DC) {
			int errorCode = parseString(line);
			switch (errorCode) {
				case 0:
					if (lc + strlen(line) > MAXADDRESS) {
						fprintf(outlist,"           ERROR: Program size exceeds available memory at line #%d\n",source_linenum);
						printf("ERROR: Program size exceeds available memory at line #%d\n",source_linenum);
								ErrorCnt++;
					}
					else {
						bool FirstStringChar = true;
						for (size_t i=0; i<strlen(line); i++) {
							fprintf(outtnc,"%03d,%05d\n",lc,line[i]);
							fprintf(outlist,"%03d  %05d",lc,line[i]);
							if (FirstStringChar) {
								fprintf(outlist,"  %3d  %s\n",source_linenum,listline);
								FirstStringChar = false;
							}
							else
								fprintf(outlist,"\n");
							lc++;
						}
					}
					break;

				case 1:
					fprintf(outlist,"            %3d  %s\n",source_linenum,listline);
					fprintf(outlist,"           ERROR: Missing or mismatched string delimiter at line #%d\n",source_linenum);
					printf("ERROR: Missing or mismatched string delimiter at line #%d\n%3d  %s\n\n",source_linenum,source_linenum,listline);
					ErrorCnt++;
					break;

				case 2: 
					fprintf(outlist,"            %3d  %s\n",source_linenum,listline);
					fprintf(outlist,"           ERROR: Missing or mismatched string delimiter at line #%d\n",source_linenum);
					printf("ERROR: Missing or mismatched string delimiter at line #%d\n%3d  %s\n\n",source_linenum,source_linenum,listline);
					ErrorCnt++;
					break;

				//default:
			}
		}
		else if (opcode == DB)
		{	if (lc > MAXADDRESS)
			{	fprintf(outlist,"           ERROR: Program size exceeds available memory at line #%d\n",source_linenum);
				printf("ERROR: Program size exceeds available memory at line #%d\n",source_linenum);
				ErrorCnt++;
				break;
			}
			if (GetNumber(line,contents))
			{	fprintf(outtnc,"%03d,%s\n",lc,fmt(contents,false));
				fprintf(outlist,"%03d %s  %3d  %s\n",lc,fmt(contents,true),source_linenum,listline);
			}
			else
			{	contents = 0;
				fprintf(outtnc,"%03d,%s\n",lc,fmt(contents,false));
				fprintf(outlist,"%03d %s  %3d  %s\n",lc,fmt(contents,true),source_linenum,listline);
				fprintf(outlist,"           ERROR: Invalid number in line #%d\n",source_linenum);
				printf("ERROR: Invalid number in line #%d:\n%3d  %s\n\n",source_linenum,source_linenum,listline);
				ErrorCnt++;
			}
			lc++;
		}
		else if (opcode == DS)
		{	if (GetNumber(line,size))
			{	if (size >= 0 && size + lc <= MAXADDRESS)
				{	fprintf(outlist,"%03d  ?????  %3d  %s\n",lc,source_linenum,listline);
					if (size == 0) {
						fprintf(outlist,"           WARNING: Zero storage request in line #%d\n",source_linenum);
						printf("WARNING: Zero storage request in line #%d:\n%3d  %s\n\n",source_linenum,source_linenum,listline);
						WarningCnt++;
					}
				}
				else if (size < 0)
				{	size = 0;
					fprintf(outlist,"            %3d  %s\n",source_linenum,listline);
					fprintf(outlist,"           ERROR: Invalid storage request in line #%d\n",source_linenum);
					printf("ERROR: Invalid storage request in line #%d:\n%3d  %s\n\n",source_linenum, source_linenum, listline);
					ErrorCnt++;
				}
				else if (size + lc > MAXADDRESS)
				{	size = MAXADDRESS - lc + 1;
					fprintf(outlist,"%03d  ?????  %3d  %s\n",lc,source_linenum,listline);
					fprintf(outlist,"           ERROR: Storage request exceeds available memory in line #%d\n",source_linenum);
					printf("ERROR: Storage request exceeds available memory in line #%d:\n%3d  %s\n\n",source_linenum, source_linenum, listline);
					ErrorCnt++;
				}
			}
			else
			{	size = 0;
				fprintf(outlist,"%03d  ?????  %3d  %s\n",lc,source_linenum,listline);
				fprintf(outlist,"           ERROR: Invalid number in line #%d\n",source_linenum);
				printf("ERROR: Invalid number in line #%d:\n%3d  %s\n\n",source_linenum, source_linenum, listline);
				ErrorCnt++;
			}
			lc += size;
		}
		else
		{	fprintf(outlist,"            %3d  %s\n",source_linenum,listline);
			if (strlen(token) > 0)
			{	printf("ERROR: Invalid opcode in line #%d:\n%3d  %s\n\n",source_linenum,source_linenum,listline);
				fprintf(outlist,"           ERROR: Invalid opcode in line #%d\n",source_linenum);
				ErrorCnt++;
			}
		}

		if (!OneLastTime)
		{
			strcpy_s(line,MAXLINE,"");
			fgets(line,MAXLINE,infile);
			if (feof(infile) && strlen(line) > 0) 
				{OneLastTime = true;}
		}
		else OneLastTime = false;

		source_linenum++;
	}

	fclose(infile);

	if (SymbolCnt > 0)
	{	fprintf(outtnc,"*START SYMBOL TABLE*\n");
		fprintf(outlist,"\n\n\t\tSYMBOL TABLE\n");
		fprintf(outlist,"\t\tADR   SYMBOL\n");
		fprintf(outlist,"\t\t---   ------\n");
		for (int i=0; i<SymbolCnt; i++)
		{	fprintf(outtnc,"%03d, %s\n",symbol_table[i].value,symbol_table[i].symbol);
			fprintf(outlist,"\t\t%03d   %s\n",symbol_table[i].value,symbol_table[i].symbol);
		}
		fprintf(outtnc,"*END SYMBOL TABLE*\n");
	}

	if (WarningCnt > 0 || ErrorCnt > 0)
	{
		printf("\n\n");
		if (WarningCnt > 0)
		{
			printf("Total number of TINY warnings: %d\n",WarningCnt);
		}
		if (ErrorCnt > 0)
		{
			printf("Total number of TINY errors: %d\n",ErrorCnt);
		}
	}

	fclose(outlist);
	fclose(outtnc);

	return true;
}

void main (int argc, char ** argv)
{	int		len;

	if (argc < 2)
	{	printf("TINY version: %s\n", VERSION);
		printf("Usage:  TINY filename.TNY\n");
		return;
	}

	strcpy_s(sourcefile,FILENAMESIZE,argv[1]);
	if (!strstr(sourcefile,"."))
		strcat_s(sourcefile,FILENAMESIZE,".tny");

	len = (int) (strstr(sourcefile,".") - sourcefile + 1);
	strncpy_s(listfile,FILENAMESIZE,sourcefile,len);
	listfile[len] = STR_TERMINAL;
	strcat_s(listfile,FILENAMESIZE,"lis");

	strncpy_s(tncfile,FILENAMESIZE,sourcefile,len);
	tncfile[len] = STR_TERMINAL;
	strcat_s(tncfile,FILENAMESIZE,"tnc");

	BuildOpcodeTable();
	if (BuildSymbolTable())
		WriteFiles();
}